//
//  AppDelegate.h
//  实时折线图
//
//  Created by 斌 on 16/9/23.
//  Copyright © 2016年 斌. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

